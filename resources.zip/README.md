
## Laravel Sanctum
<p align="center"><a href="https://laravel.com/docs/10.x/sanctum">Laravel Sanctum page</a></p>


## Laravel OTP
<p align="center">
<a href="https://github.com/ichtrojan/laravel-otp">Laravel OTP </a>
</p>


# MediXpert-Back-End Project
