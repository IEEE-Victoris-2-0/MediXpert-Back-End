<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Api\ApiResponseTrait;
class Order_detailsController extends Controller
{
    use ApiResponseTrait;

    //
}
