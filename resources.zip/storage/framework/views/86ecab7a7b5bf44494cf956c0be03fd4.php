<?php echo e($slot); ?>

<?php /**PATH C:\Users\Ahmedtamee\MediXpert-Back-End\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>