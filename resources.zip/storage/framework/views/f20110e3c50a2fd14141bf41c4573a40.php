[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Users\Ahmedtamee\MediXpert-Back-End\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>